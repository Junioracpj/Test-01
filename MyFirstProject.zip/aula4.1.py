#Coleções(listas)
'''
exemplo 5 - some os valores
Dados uma coleção de dados e idades [15,45,75,34,23]
imprima na tela a soma destes valores

idades = [15,45,75,34,23]
total = 0
loop idade em idades
 total =  total + idade
print total
'''

idades = [15,45,75,34,23]
total = 0
for idade in idades:
  total = total +idade
print(total)