#Coleções(listas)
preco2 = 20
preco1 = 50
preco3 = 200
#listas
precos = [20,50,200]
# indicadores das listas começam a partir de 0,1,2
print(precos[1])
print(precos.index(200)) 
#indica o indice no numero 200

#lista
diversidades = [15,'jonatan', True]
print(diversidades[0])
print(diversidades[1])
print(diversidades[2])
#lacos de repeticao
for preco in precos:
  print(precos)