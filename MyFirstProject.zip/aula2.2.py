#condicionais
#if, elif e else
'''
eu cheguei atrasado na aula, ainda posso entrar?
se essa nao for sua terceira vez chegando atrasado, pode sim, caso contrário irá tomar uma suspensão.
'''
numero_atrasos = 4
if numero_atrasos >= 3:
  print ('voce esta suspenso')
elif numero_atrasos == 1 :
  print ('pode entrar, porem caso tome mais 2 faltas, ira ser suspenso')
elif numero_atrasos == 2 :
  print ('pode entrar, porem caso tome mais 1 falta, ira ser suspenso')
else :
  print ('pode entrar')