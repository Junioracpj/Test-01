#laços de repetição + listas
for palavra in range(1,4):
  print('carregando')
  '''
  for item in coleção:
  espressão
  '''
for item in range(1,20):
  print(item)
for item in range(1,20,2):
  print(item)

nomes = ['jonathan','cristian','roberto','camila']
for nome in nomes:
  print(nome)