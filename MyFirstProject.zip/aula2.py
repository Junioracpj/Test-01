#condicionais
#if, elif e else
'''
e ai jonatan, bora dar uma saida hoje?
se eu terminar o trabalho aqui, eu consigo
'''
trabalho_terminado = True
if trabalho_terminado == True:
  print ('opa! bora dar uma saida.')
else:
  print('nao posso sair agora.')