#laços de repetição + listas
'''
input numero maximo
valor inicial = 1 
loop de valor_inicial a numero_maximo
 print valor
'''

valor_maximo = int(input('digite o valor maximo'))
valor_inicial = 1
for numero in range(valor_inicial, valor_maximo + 3):
  print(numero)