#variaveis

#numeros
velocidade_internet = 10
print (velocidade_internet)
#float
nota_filme = 8.5 #numeros com decimais
#valores boleanos
esta_aberto = True #variaveis para condicionar
#strings
nome_do_curso = 'logica de programação' # palavras
'''
input salario_mensal
input horas_trabalhadas_por_mes
Valor_hora = salario_mensal / horas_trabalhadas_por_mes
print valor_hora
'''
salario_mensal = input('qual é o seu salario mensal')
horas_trabalhadas_mes = input('quantas horas você trabalha por mes')
valor_hora = int(salario_mensal) / int(horas_trabalhadas_mes)
print(valor_hora)