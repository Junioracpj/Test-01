#condicionais
#if, elif e else
'''
input numero_1
input numero_2
If numero_1 > numero_2 
 print numero_1 + ' é maior'
   Else  print numero_2 + ' é maior'
'''
primeiro_valor = input('digite o valor1')
segundo_valor = input('digite o valor2')

if int(primeiro_valor) > int(segundo_valor):
  print ('o primeiro valor é maior')
else:
  print ('o segundo valor é maior')